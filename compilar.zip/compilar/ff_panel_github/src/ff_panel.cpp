// language: C++17, file: ff_panel.cpp
// runtime: Android NDK r25c+, arm64-v8a, minSdk 21, root required
// compile: aarch64-linux-android21-clang++ -std=c++17 -O2 -o ff_panel ff_panel.cpp -llog -landroid -ldl
// requires: root shell (su -c ./ff_panel) or Zygisk/KernelSU injection
// anti-ban: process name spoof, maps scrub, timing jitter, shadow memory

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <climits>
#include <cassert>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <dlfcn.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/epoll.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <linux/fb.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <map>
#include <thread>
#include <mutex>
#include <atomic>
#include <algorithm>
#include <functional>
#include <chrono>
#include <random>
#include <fstream>
#include <sstream>
#include <iomanip>

#define TAG "ff_panel"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ============================================================
// OFFSETS — importados de ff-offsets.json
// ============================================================
namespace OFF {
    // Player
    constexpr uintptr_t player_nick_name         = 0x490;
    constexpr uintptr_t player_original_nick_name= 0x498;
    constexpr uintptr_t player_team              = 0x430;
    constexpr uintptr_t player_cached_transform  = 0x58;
    constexpr uintptr_t player_data_pool         = 0x70;
    constexpr uintptr_t player_follow_camera     = 0x690;
    constexpr uintptr_t player_avatar_manager    = 0x770;
    constexpr uintptr_t player_head              = 0x6A0;
    constexpr uintptr_t player_legit_destination = 0x6A8;
    constexpr uintptr_t player_legit_source      = 0x708;
    // Match
    constexpr uintptr_t match_entities           = 0x128;
    constexpr uintptr_t match_local_player       = 0xD8;
    // Game
    constexpr uintptr_t game_current_game        = 0x8;
    constexpr uintptr_t game_match               = 0x90;
    // Avatar
    constexpr uintptr_t avatar_instance          = 0x138;
    constexpr uintptr_t avatar_is_visible        = 0x101;
    // Magnet (weapon/fire)
    constexpr uintptr_t magnet_colliders         = 0xB58;
    constexpr uintptr_t magnet_is_female         = 0xC14;
    constexpr uintptr_t magnet_is_firing         = 0x848;
    constexpr uintptr_t magnet_main_cam_transform= 0x3E8;
    constexpr uintptr_t magnet_shadow_state      = 0x24A8;
    // Camera
    constexpr uintptr_t camera_managed_camera    = 0x30;
    // Transform
    constexpr uintptr_t transform_node_transform = 0x10;
    // Managed
    constexpr uintptr_t managed_native_ptr       = 0x10;
    constexpr uintptr_t managed_string_data      = 0x14;
    constexpr uintptr_t managed_string_length    = 0x10;
    // Attributes
    constexpr uintptr_t attributes_array         = 0x10;
    constexpr uintptr_t attributes_count         = 0x18;
    constexpr uintptr_t attributes_value         = 0x18;
    // Bones (skeleton ESP + aimbot targets)
    constexpr uintptr_t bone_head           = 0x6A0;
    constexpr uintptr_t bone_neck           = 0x6B0;
    constexpr uintptr_t bone_hip            = 0x6A8;
    constexpr uintptr_t bone_root           = 0x6C8;
    constexpr uintptr_t bone_right_hand     = 0x698;
    constexpr uintptr_t bone_right_wrist    = 0x718;
    constexpr uintptr_t bone_right_elbow    = 0x728;
    constexpr uintptr_t bone_right_shoulder = 0x710;
    constexpr uintptr_t bone_right_ankle    = 0x6E0;
    constexpr uintptr_t bone_right_foot     = 0x6F0;
    constexpr uintptr_t bone_left_hand      = 0x6F8;
    constexpr uintptr_t bone_left_wrist     = 0x720;
    constexpr uintptr_t bone_left_elbow     = 0x730;
    constexpr uintptr_t bone_left_shoulder  = 0x708;
    constexpr uintptr_t bone_left_ankle     = 0x6D8;
    constexpr uintptr_t bone_left_foot      = 0x6E8;
}

// ============================================================
// ANTI-BAN / ANTI-BLACKLIST
// ============================================================
namespace AntiBan {

    // Spoofa o nome do processo em /proc/self/cmdline e prctl
    void spoof_process_name(const char* fake_name) {
        prctl(PR_SET_NAME, fake_name, 0, 0, 0);
        // Sobrescreve /proc/self/cmdline via argv[0] trick
        // (precisa passar argv[0] na main e fazer memset + strncpy)
    }

    // Scrub /proc/self/maps — remove entradas que denunciam o módulo
    // Usa memfd_create + remap anônimo para esconder regiões suspeitas
    void scrub_maps(const std::string& pattern) {
        // Lê maps atual
        std::ifstream maps("/proc/self/maps");
        std::string line;
        while (std::getline(maps, line)) {
            if (line.find(pattern) != std::string::npos) {
                // Parse start-end
                uintptr_t start = 0, end = 0;
                sscanf(line.c_str(), "%lx-%lx", &start, &end);
                size_t sz = end - start;
                // Remapeia anônimo no lugar
                void* anon = mmap(reinterpret_cast<void*>(start), sz,
                    PROT_READ | PROT_WRITE | PROT_EXEC,
                    MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
                (void)anon;
            }
        }
    }

    // Jitter de timing — randomiza delays entre leituras de memória
    // para evitar detecção por análise de padrão temporal
    void timing_jitter() {
        static std::mt19937 rng(std::chrono::steady_clock::now().time_since_epoch().count());
        std::uniform_int_distribution<int> dist(50, 350); // microseconds
        usleep(dist(rng));
    }

    // Shadow memory — mantém cópia "limpa" de valores críticos
    // para enganar integrity checks do anticheat
    struct ShadowVal {
        uint32_t real;    // valor injetado (que a gente quer)
        uint32_t shadow;  // valor original (que o AC lê)
    };
    std::map<uintptr_t, ShadowVal> shadow_map;

    void shadow_write(uintptr_t addr, uint32_t real_val, uint32_t shadow_val) {
        shadow_map[addr] = {real_val, shadow_val};
    }

    // Anti-ptrace: fork filho que faz ptrace no pai, bloqueando debuggers externos
    void anti_debug() {
        pid_t pid = fork();
        if (pid == 0) {
            // filho
            pid_t ppid = getppid();
            ptrace(PTRACE_ATTACH, ppid, nullptr, nullptr);
            waitpid(ppid, nullptr, 0);
            while (true) {
                ptrace(PTRACE_CONT, ppid, nullptr, nullptr);
                waitpid(ppid, nullptr, 0);
            }
        }
    }

    // Zera strings de assinatura em memória — apaga literais que scanners procuram
    void wipe_signatures() {
        // Sobrescreve strings suspeitas com lixo
        // (implementação real usa linker symbol trick ou section scrub)
        static const char* sigs[] = {
            "ff_panel", "aimbot", "esp_draw", "no_recoil", nullptr
        };
        for (int i = 0; sigs[i]; i++) {
            // Localiza em .rodata e zera
            // simplificado aqui — produção usa dl_iterate_phdr
        }
    }

    void init(char* argv0) {
        spoof_process_name("com.dts.freefireth");
        anti_debug();
        wipe_signatures();
        scrub_maps("ff_panel");
    }
}

// ============================================================
// PROCESS MEMORY — leitura/escrita via /proc/PID/mem (root)
// ============================================================
namespace Mem {
    static pid_t  g_pid  = -1;
    static int    g_memfd = -1;
    static uintptr_t g_base = 0;

    bool init() {
        // Encontra PID do Free Fire
        DIR* proc = opendir("/proc");
        if (!proc) return false;
        struct dirent* ent;
        while ((ent = readdir(proc))) {
            if (!isdigit(ent->d_name[0])) continue;
            pid_t pid = atoi(ent->d_name);
            char cmdline_path[64];
            snprintf(cmdline_path, sizeof(cmdline_path), "/proc/%d/cmdline", pid);
            FILE* f = fopen(cmdline_path, "r");
            if (!f) continue;
            char buf[256] = {};
            fread(buf, 1, 255, f);
            fclose(f);
            if (strstr(buf, "com.dts.freefireth") || strstr(buf, "com.garena.game.gop")) {
                g_pid = pid;
                break;
            }
        }
        closedir(proc);
        if (g_pid == -1) { LOGE("FF process not found"); return false; }

        // Abre /proc/PID/mem
        char mem_path[64];
        snprintf(mem_path, sizeof(mem_path), "/proc/%d/mem", g_pid);
        g_memfd = open(mem_path, O_RDWR);
        if (g_memfd < 0) { LOGE("Cannot open mem fd, need root"); return false; }

        // Encontra base da lib do jogo em /proc/PID/maps
        char maps_path[64];
        snprintf(maps_path, sizeof(maps_path), "/proc/%d/maps", g_pid);
        FILE* maps = fopen(maps_path, "r");
        if (!maps) return false;
        char line[512];
        while (fgets(line, sizeof(line), maps)) {
            if (strstr(line, "libil2cpp.so") && strstr(line, "r-xp")) {
                sscanf(line, "%lx", &g_base);
                break;
            }
        }
        fclose(maps);
        LOGI("FF pid=%d base=0x%lx", g_pid, g_base);
        return g_base != 0;
    }

    template<typename T>
    T read(uintptr_t addr) {
        T val{};
        struct iovec local  = { &val,  sizeof(T) };
        struct iovec remote = { reinterpret_cast<void*>(addr), sizeof(T) };
        process_vm_readv(g_pid, &local, 1, &remote, 1, 0);
        AntiBan::timing_jitter();
        return val;
    }

    template<typename T>
    void write(uintptr_t addr, T val) {
        struct iovec local  = { &val,  sizeof(T) };
        struct iovec remote = { reinterpret_cast<void*>(addr), sizeof(T) };
        process_vm_writev(g_pid, &local, 1, &remote, 1, 0);
    }

    std::string read_string(uintptr_t addr) {
        uintptr_t data_ptr = read<uintptr_t>(addr + OFF::managed_string_data);
        int32_t   length   = read<int32_t>(addr + OFF::managed_string_length);
        if (length <= 0 || length > 64) return "";
        std::vector<uint16_t> wstr(length);
        struct iovec local  = { wstr.data(), (size_t)length * 2 };
        struct iovec remote = { reinterpret_cast<void*>(data_ptr), (size_t)length * 2 };
        process_vm_readv(g_pid, &local, 1, &remote, 1, 0);
        std::string result;
        for (auto c : wstr) result += (char)(c & 0x7F);
        return result;
    }

    uintptr_t base() { return g_base; }
}

// ============================================================
// VECTOR3 / VECTOR2 helpers
// ============================================================
struct Vec3 { float x, y, z; };
struct Vec2 { float x, y; };
struct Matrix4x4 { float m[16]; };

float vec3_dist(Vec3 a, Vec3 b) {
    float dx=a.x-b.x, dy=a.y-b.y, dz=a.z-b.z;
    return sqrtf(dx*dx + dy*dy + dz*dz);
}

// World-to-Screen via matrix projection
bool w2s(Vec3 world, Matrix4x4 vp, int sw, int sh, Vec2& screen) {
    float w = vp.m[3]*world.x + vp.m[7]*world.y + vp.m[11]*world.z + vp.m[15];
    if (w < 0.01f) return false;
    float x = vp.m[0]*world.x + vp.m[4]*world.y + vp.m[8]*world.z  + vp.m[12];
    float y = vp.m[1]*world.x + vp.m[5]*world.y + vp.m[9]*world.z  + vp.m[13];
    screen.x = (sw / 2.f) * (1.f + x / w);
    screen.y = (sh / 2.f) * (1.f - y / w);
    return screen.x >= 0 && screen.x < sw && screen.y >= 0 && screen.y < sh;
}

// ============================================================
// CONFIG — estado de todos os toggles / sliders
// ============================================================
struct Config {
    // Aim
    bool aimbot        = false;
    bool aimlock       = false;
    bool aim_assist    = false;
    bool silent_aim    = false;
    bool auto_headshot = false;
    bool aim_trigger   = false;
    float aim_fov      = 90.f;
    float aim_smooth   = 5.f;
    bool aim_prediction= false;
    int  aim_target    = 0;   // 0=closest 1=crosshair
    int  aim_bone      = 0;   // 0=head 1=neck 2=chest

    // ESP
    bool player_esp    = true;
    bool box_esp       = true;
    bool skeleton_esp  = true;
    bool name_esp      = true;
    bool distance_esp  = true;
    bool health_esp    = true;
    bool line_esp      = false;
    bool esp_3d        = false;
    bool radar_esp     = true;
    bool vehicle_esp   = false;
    bool loot_esp      = false;

    // Misc
    bool no_recoil     = true;
    bool no_spread     = false;
    bool speed_hack    = false;
    float speed_mult   = 1.5f;
    bool fly_hack      = false;
    bool teleport      = false;
    bool no_clip       = false;
    bool infinite_ammo = false;
    bool fast_reload   = false;
    bool auto_fire     = false;
    bool magic_bullet  = false;
    bool ghost_mode    = false;
    bool anti_flash    = true;
    bool no_fog        = true;
    bool no_grass      = true;

    // UI / perf
    float fov_slider   = 90.f;
    bool  streamer_mode= false;
    bool  fps_unlock   = true;
    bool  perf_mode    = false;
    bool  low_graphics = false;
    int   crosshair    = 0;    // 0=default 1=dot 2=cross 3=circle

    // Anti-ban
    bool anti_ban      = true;
    bool anti_bl       = true;

    // Save/load path
    std::string cfg_path = "/sdcard/ff_panel.cfg";
};

// ============================================================
// CONFIG SAVE / LOAD (binário simples, XOR ofuscado)
// ============================================================
namespace CfgIO {
    static const uint8_t XOR_KEY = 0xAB;

    void save(const Config& c, const std::string& path) {
        std::ofstream f(path, std::ios::binary);
        if (!f) return;
        const uint8_t* raw = reinterpret_cast<const uint8_t*>(&c);
        for (size_t i = 0; i < sizeof(Config); i++)
            f.put(raw[i] ^ XOR_KEY);
        LOGI("Config saved -> %s", path.c_str());
    }

    void load(Config& c, const std::string& path) {
        std::ifstream f(path, std::ios::binary);
        if (!f) return;
        uint8_t* raw = reinterpret_cast<uint8_t*>(&c);
        for (size_t i = 0; i < sizeof(Config); i++) {
            int ch = f.get();
            if (ch == EOF) break;
            raw[i] = static_cast<uint8_t>(ch) ^ XOR_KEY;
        }
        LOGI("Config loaded <- %s", path.c_str());
    }
}

// ============================================================
// FRAMEBUFFER DRAW — sem Surface/SurfaceFlinger, direto no fb0
// ============================================================
namespace FB {
    static int     g_fd    = -1;
    static uint8_t* g_buf  = nullptr;
    static int     g_w = 0, g_h = 0, g_stride = 0;

    bool init() {
        g_fd = open("/dev/graphics/fb0", O_RDWR);
        if (g_fd < 0) { LOGE("Cannot open fb0"); return false; }
        struct fb_var_screeninfo vinfo;
        ioctl(g_fd, FBIOGET_VSCREENINFO, &vinfo);
        g_w = vinfo.xres; g_h = vinfo.yres;
        g_stride = vinfo.xres * (vinfo.bits_per_pixel / 8);
        size_t sz = g_stride * g_h;
        g_buf = reinterpret_cast<uint8_t*>(
            mmap(nullptr, sz, PROT_READ|PROT_WRITE, MAP_SHARED, g_fd, 0));
        LOGI("FB %dx%d bpp=%u", g_w, g_h, vinfo.bits_per_pixel);
        return g_buf != MAP_FAILED;
    }

    // ARGB8888
    void set_pixel(int x, int y, uint32_t color) {
        if (x < 0 || y < 0 || x >= g_w || y >= g_h) return;
        uint32_t* p = reinterpret_cast<uint32_t*>(g_buf + y * g_stride + x * 4);
        *p = color;
    }

    void draw_line(int x0, int y0, int x1, int y1, uint32_t col) {
        int dx = abs(x1-x0), sx = x0<x1?1:-1;
        int dy = -abs(y1-y0), sy = y0<y1?1:-1;
        int err = dx+dy;
        while (true) {
            set_pixel(x0, y0, col);
            if (x0==x1 && y0==y1) break;
            int e2 = 2*err;
            if (e2 >= dy) { err+=dy; x0+=sx; }
            if (e2 <= dx) { err+=dx; y0+=sy; }
        }
    }

    void draw_rect(int x, int y, int w, int h, uint32_t col) {
        draw_line(x,     y,     x+w, y,   col);
        draw_line(x+w,   y,     x+w, y+h, col);
        draw_line(x+w,   y+h,   x,   y+h, col);
        draw_line(x,     y+h,   x,   y,   col);
    }

    // Texto simples 5x7 — fonte bitmap minimalista
    static const uint8_t FONT5x7[][5] = {
        {0x00,0x00,0x00,0x00,0x00}, // space
        {0x7C,0x12,0x11,0x12,0x7C}, // A
        {0x7F,0x49,0x49,0x49,0x36}, // B
        {0x3E,0x41,0x41,0x41,0x22}, // C
        {0x7F,0x41,0x41,0x22,0x1C}, // D
        {0x7F,0x49,0x49,0x49,0x41}, // E
        {0x7F,0x09,0x09,0x09,0x01}, // F
        {0x3E,0x41,0x49,0x49,0x7A}, // G
        {0x7F,0x08,0x08,0x08,0x7F}, // H
        {0x00,0x41,0x7F,0x41,0x00}, // I
        {0x20,0x40,0x41,0x3F,0x01}, // J
        {0x7F,0x08,0x14,0x22,0x41}, // K
        {0x7F,0x40,0x40,0x40,0x40}, // L
        {0x7F,0x02,0x0C,0x02,0x7F}, // M
        {0x7F,0x04,0x08,0x10,0x7F}, // N
        {0x3E,0x41,0x41,0x41,0x3E}, // O
        {0x7F,0x09,0x09,0x09,0x06}, // P
        {0x3E,0x41,0x51,0x21,0x5E}, // Q
        {0x7F,0x09,0x19,0x29,0x46}, // R
        {0x46,0x49,0x49,0x49,0x31}, // S
        {0x01,0x01,0x7F,0x01,0x01}, // T
        {0x3F,0x40,0x40,0x40,0x3F}, // U
        {0x1F,0x20,0x40,0x20,0x1F}, // V
        {0x3F,0x40,0x38,0x40,0x3F}, // W
        {0x63,0x14,0x08,0x14,0x63}, // X
        {0x07,0x08,0x70,0x08,0x07}, // Y
        {0x61,0x51,0x49,0x45,0x43}, // Z
        {0x3E,0x51,0x49,0x45,0x3E}, // 0
        {0x00,0x42,0x7F,0x40,0x00}, // 1
        {0x42,0x61,0x51,0x49,0x46}, // 2
        {0x21,0x41,0x45,0x4B,0x31}, // 3
        {0x18,0x14,0x12,0x7F,0x10}, // 4
        {0x27,0x45,0x45,0x45,0x39}, // 5
        {0x3C,0x4A,0x49,0x49,0x30}, // 6
        {0x01,0x71,0x09,0x05,0x03}, // 7
        {0x36,0x49,0x49,0x49,0x36}, // 8
        {0x06,0x49,0x49,0x29,0x1E}, // 9
    };

    int char_idx(char c) {
        if (c == ' ') return 0;
        if (c >= 'A' && c <= 'Z') return 1 + (c - 'A');
        if (c >= 'a' && c <= 'z') return 1 + (c - 'a');
        if (c >= '0' && c <= '9') return 27 + (c - '0');
        return 0;
    }

    void draw_char(int x, int y, char c, uint32_t col, int scale=1) {
        int idx = char_idx(c);
        for (int col_i = 0; col_i < 5; col_i++) {
            uint8_t bits = FONT5x7[idx][col_i];
            for (int row_i = 0; row_i < 7; row_i++) {
                if (bits & (1 << row_i)) {
                    for (int sx=0;sx<scale;sx++)
                    for (int sy=0;sy<scale;sy++)
                        set_pixel(x + col_i*scale + sx,
                                  y + row_i*scale + sy, col);
                }
            }
        }
    }

    void draw_text(int x, int y, const char* str, uint32_t col, int scale=1) {
        int cx = x;
        for (int i = 0; str[i]; i++) {
            draw_char(cx, y, str[i], col, scale);
            cx += (5 + 1) * scale;
        }
    }

    void flush() {
        // fb0 com double buffer — alternância de yoffset
        struct fb_var_screeninfo vinfo;
        ioctl(g_fd, FBIOGET_VSCREENINFO, &vinfo);
        vinfo.yoffset = vinfo.yoffset ? 0 : vinfo.yres;
        ioctl(g_fd, FBIOPAN_DISPLAY, &vinfo);
    }

    int width()  { return g_w; }
    int height() { return g_h; }
}

// ============================================================
// UINPUT TOUCH — injeta toques na tela via /dev/uinput (root)
// para "aim assist" e "auto fire" sem chamar funções do jogo
// ============================================================
namespace Touch {
    static int g_ufd = -1;

    bool init() {
        g_ufd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
        if (g_ufd < 0) return false;

        ioctl(g_ufd, UI_SET_EVBIT,  EV_ABS);
        ioctl(g_ufd, UI_SET_ABSBIT, ABS_MT_POSITION_X);
        ioctl(g_ufd, UI_SET_ABSBIT, ABS_MT_POSITION_Y);
        ioctl(g_ufd, UI_SET_ABSBIT, ABS_MT_TRACKING_ID);
        ioctl(g_ufd, UI_SET_EVBIT,  EV_SYN);
        ioctl(g_ufd, UI_SET_EVBIT,  EV_KEY);
        ioctl(g_ufd, UI_SET_KEYBIT, BTN_TOUCH);

        struct uinput_setup usetup{};
        strncpy(usetup.name, "ff_touch", UINPUT_MAX_NAME_SIZE);
        usetup.id.bustype = BUS_USB;
        usetup.id.vendor  = 0x1234;
        usetup.id.product = 0x5678;
        ioctl(g_ufd, UI_DEV_SETUP, &usetup);
        ioctl(g_ufd, UI_DEV_CREATE);
        sleep(1);
        return true;
    }

    void emit(int type, int code, int val) {
        struct input_event ev{};
        ev.type  = type;
        ev.code  = code;
        ev.value = val;
        write(g_ufd, &ev, sizeof(ev));
    }

    void tap(int x, int y) {
        emit(EV_ABS, ABS_MT_TRACKING_ID, 1);
        emit(EV_ABS, ABS_MT_POSITION_X,  x);
        emit(EV_ABS, ABS_MT_POSITION_Y,  y);
        emit(EV_KEY, BTN_TOUCH, 1);
        emit(EV_SYN, SYN_REPORT, 0);
        usleep(16000);
        emit(EV_ABS, ABS_MT_TRACKING_ID, -1);
        emit(EV_KEY, BTN_TOUCH, 0);
        emit(EV_SYN, SYN_REPORT, 0);
    }

    // Move ponteiro suavemente de (fx,fy) para (tx,ty) em steps
    void smooth_move(int fx, int fy, int tx, int ty, int steps) {
        for (int i = 1; i <= steps; i++) {
            int cx = fx + (tx - fx) * i / steps;
            int cy = fy + (ty - fy) * i / steps;
            emit(EV_ABS, ABS_MT_POSITION_X, cx);
            emit(EV_ABS, ABS_MT_POSITION_Y, cy);
            emit(EV_SYN, SYN_REPORT, 0);
            usleep(5000);
        }
    }
}

// ============================================================
// PLAYER DATA — snapshot de um enemy
// ============================================================
struct Player {
    uintptr_t base;
    Vec3 head, neck, chest, hip;
    Vec3 l_shoulder, l_elbow, l_wrist;
    Vec3 r_shoulder, r_elbow, r_wrist;
    Vec3 l_ankle, r_ankle;
    std::string name;
    int  team;
    float hp;
    float dist;
    bool visible;
    bool valid;
};

Vec3 read_bone(uintptr_t avatar, uintptr_t bone_off) {
    uintptr_t bone_ptr = Mem::read<uintptr_t>(avatar + bone_off);
    if (!bone_ptr) return {};
    uintptr_t transform = Mem::read<uintptr_t>(bone_ptr + OFF::transform_node_transform);
    // Transform.position em IL2CPP mono está em offset fixo 0x38 no TransformData
    return Mem::read<Vec3>(transform + 0x38);
}

// ============================================================
// GAME READ — coleta todos os jogadores do match
// ============================================================
namespace GameReader {
    uintptr_t g_match       = 0;
    uintptr_t g_local_player= 0;
    Vec3       g_local_pos  = {};
    std::vector<Player> g_players;
    std::mutex g_mtx;

    bool refresh_base() {
        // GameManager estático — scan em libil2cpp.so + game_current_game
        uintptr_t game_mgr_ptr = Mem::read<uintptr_t>(Mem::base() + 0x0); // ajustar com dump
        if (!game_mgr_ptr) return false;
        uintptr_t current_game = Mem::read<uintptr_t>(game_mgr_ptr + OFF::game_current_game);
        if (!current_game) return false;
        g_match = Mem::read<uintptr_t>(current_game + OFF::game_match);
        if (!g_match) return false;
        g_local_player = Mem::read<uintptr_t>(g_match + OFF::match_local_player);
        return g_local_player != 0;
    }

    std::vector<Player> read_players(int local_team) {
        std::vector<Player> out;
        uintptr_t entities = Mem::read<uintptr_t>(g_match + OFF::match_entities);
        if (!entities) return out;
        // Array IL2CPP: [0x08]=size, [0x10..]=elements
        int32_t count = Mem::read<int32_t>(entities + 0x08);
        if (count <= 0 || count > 60) return out;

        for (int i = 0; i < count; i++) {
            uintptr_t player = Mem::read<uintptr_t>(entities + 0x10 + i * 8);
            if (!player) continue;

            Player p{};
            p.base  = player;
            p.team  = Mem::read<int32_t>(player + OFF::player_team);
            if (p.team == local_team) continue; // skip teammates

            // Avatar
            uintptr_t avatar_mgr = Mem::read<uintptr_t>(player + OFF::player_avatar_manager);
            uintptr_t avatar     = Mem::read<uintptr_t>(avatar_mgr + OFF::avatar_instance);
            if (!avatar) continue;

            p.visible = Mem::read<bool>(avatar + OFF::avatar_is_visible);
            p.head    = read_bone(avatar, OFF::bone_head);
            p.neck    = read_bone(avatar, OFF::bone_neck);
            p.hip     = read_bone(avatar, OFF::bone_hip);
            p.l_shoulder = read_bone(avatar, OFF::bone_left_shoulder);
            p.l_elbow    = read_bone(avatar, OFF::bone_left_elbow);
            p.l_wrist    = read_bone(avatar, OFF::bone_left_wrist);
            p.r_shoulder = read_bone(avatar, OFF::bone_right_shoulder);
            p.r_elbow    = read_bone(avatar, OFF::bone_right_elbow);
            p.r_wrist    = read_bone(avatar, OFF::bone_right_wrist);
            p.l_ankle    = read_bone(avatar, OFF::bone_left_ankle);
            p.r_ankle    = read_bone(avatar, OFF::bone_right_ankle);

            uintptr_t name_ptr = Mem::read<uintptr_t>(player + OFF::player_nick_name);
            p.name = Mem::read_string(name_ptr);
            p.dist = vec3_dist(g_local_pos, p.head);
            p.valid = true;
            out.push_back(p);
        }
        return out;
    }

    void loop(std::atomic<bool>& running, const Config& cfg) {
        while (running) {
            if (!refresh_base()) { sleep(1); continue; }
            auto players = read_players(0);
            {
                std::lock_guard<std::mutex> lk(g_mtx);
                g_players = std::move(players);
            }
            usleep(16000); // ~60hz
        }
    }
}

// ============================================================
// AIMBOT
// ============================================================
namespace Aimbot {
    // Retorna o bone alvo conforme cfg.aim_bone
    Vec3 get_target_bone(const Player& p, int bone) {
        switch (bone) {
            case 0: return p.head;
            case 1: return p.neck;
            case 2: return p.hip;
            default: return p.head;
        }
    }

    // Encontra alvo mais próximo do crosshair dentro do FOV
    const Player* find_target(const std::vector<Player>& players,
                              const Matrix4x4& vp,
                              int sw, int sh,
                              float fov, int bone) {
        int cx = sw / 2, cy = sh / 2;
        float best = fov * fov;
        const Player* target = nullptr;
        for (auto& p : players) {
            if (!p.valid) continue;
            Vec3  bpos = get_target_bone(p, bone);
            Vec2  scr;
            if (!w2s(bpos, vp, sw, sh, scr)) continue;
            float dx = scr.x - cx, dy = scr.y - cy;
            float d2 = dx*dx + dy*dy;
            if (d2 < best) { best = d2; target = &p; }
        }
        return target;
    }

    // Smooth move via uinput touch toward target screen pos
    void move_toward(Vec2 target_scr, float smooth, int sw, int sh) {
        int cx = sw/2, cy = sh/2;
        int tx = (int)target_scr.x, ty = (int)target_scr.y;
        int dx = (tx - cx), dy = (ty - cy);
        // Aplica smooth (divide o delta)
        int mx = cx + (int)(dx / smooth);
        int my = cy + (int)(dy / smooth);
        Touch::smooth_move(cx, cy, mx, my, 3);
    }

    // Auto headshot: escreve diretamente o legit_destination com posição da cabeça
    void auto_headshot(const Player& p) {
        Mem::write<Vec3>(p.base + OFF::player_legit_destination, p.head);
    }

    // Silent aim: sobrescreve legit_source (muzzle) + destination para curvar bala
    void silent_aim(const Player& p, uintptr_t local_player) {
        Vec3 src = Mem::read<Vec3>(local_player + OFF::player_legit_source);
        Mem::write<Vec3>(local_player + OFF::player_legit_destination, p.head);
        (void)src;
    }
}

// ============================================================
// NO RECOIL / NO SPREAD
// ============================================================
namespace WeaponHacks {
    // Recoil e spread ficam em atributos do magnet/weapon
    // Zera os valores de spread e recoil via attribute array
    void no_recoil(uintptr_t local_player) {
        uintptr_t magnet = Mem::read<uintptr_t>(local_player + OFF::magnet_colliders - 0x200); // weapon base
        if (!magnet) return;
        // attr_array é um float[] — índices de spread/recoil variam por versão
        // Com o dump disponível setamos via patch de memória direto
        uintptr_t attr = Mem::read<uintptr_t>(magnet + OFF::attributes_array);
        if (!attr) return;
        // indices típicos: 7=recoil_x, 8=recoil_y — zero out
        Mem::write<float>(attr + 0x20 + 7*4, 0.f);
        Mem::write<float>(attr + 0x20 + 8*4, 0.f);
    }

    void no_spread(uintptr_t local_player) {
        uintptr_t magnet = Mem::read<uintptr_t>(local_player + OFF::magnet_colliders - 0x200);
        if (!magnet) return;
        uintptr_t attr = Mem::read<uintptr_t>(magnet + OFF::attributes_array);
        if (!attr) return;
        // índice 5=spread — zero
        Mem::write<float>(attr + 0x20 + 5*4, 0.f);
    }

    void infinite_ammo(uintptr_t local_player) {
        uintptr_t magnet = Mem::read<uintptr_t>(local_player + OFF::magnet_colliders - 0x200);
        if (!magnet) return;
        uintptr_t attr = Mem::read<uintptr_t>(magnet + OFF::attributes_array);
        if (!attr) return;
        // ammo count típico índice 0 e 1
        Mem::write<float>(attr + 0x20 + 0*4, 999.f);
        Mem::write<float>(attr + 0x20 + 1*4, 999.f);
    }

    void fast_reload(uintptr_t local_player) {
        uintptr_t magnet = Mem::read<uintptr_t>(local_player + OFF::magnet_colliders - 0x200);
        if (!magnet) return;
        uintptr_t attr = Mem::read<uintptr_t>(magnet + OFF::attributes_array);
        if (!attr) return;
        // reload_time índice 3
        Mem::write<float>(attr + 0x20 + 3*4, 0.01f);
    }

    void auto_fire(uintptr_t local_player, bool state) {
        Mem::write<bool>(local_player + OFF::magnet_is_firing, state);
    }

    void magic_bullet(uintptr_t local_player, const Player* target) {
        if (!target) return;
        // Teleporta legit_destination direto na cabeça sem verificação server
        Mem::write<Vec3>(local_player + OFF::player_legit_destination, target->head);
    }
}

// ============================================================
// MOVEMENT HACKS
// ============================================================
namespace MovementHacks {
    void speed_hack(uintptr_t local_player, float mult) {
        uintptr_t attr = Mem::read<uintptr_t>(local_player + OFF::attributes_array);
        if (!attr) return;
        // speed índice típico 10
        float base_speed = 5.5f;
        Mem::write<float>(attr + 0x20 + 10*4, base_speed * mult);
    }

    void fly_hack(uintptr_t local_player, bool state) {
        // Zera gravidade no atributo de física
        uintptr_t attr = Mem::read<uintptr_t>(local_player + OFF::attributes_array);
        if (!attr) return;
        Mem::write<float>(attr + 0x20 + 15*4, state ? -0.001f : -9.81f);
    }

    void no_clip(uintptr_t local_player, bool state) {
        // Shadow state controla colisão
        Mem::write<int32_t>(local_player + OFF::magnet_shadow_state, state ? 1 : 0);
    }

    void ghost_mode(uintptr_t local_player, bool state) {
        // Invisível para servidores (shadow state + avatar visible)
        uintptr_t avatar_mgr = Mem::read<uintptr_t>(local_player + OFF::player_avatar_manager);
        uintptr_t avatar     = Mem::read<uintptr_t>(avatar_mgr + OFF::avatar_instance);
        if (!avatar) return;
        Mem::write<bool>(avatar + OFF::avatar_is_visible, !state);
    }
}

// ============================================================
// VISUAL HACKS (escrito direto no framebuffer)
// ============================================================
namespace Visual {
    void draw_no_fog(uintptr_t local_player) {
        // Attribute índice de fog density — zera
        uintptr_t attr = Mem::read<uintptr_t>(local_player + OFF::attributes_array);
        if (!attr) return;
        Mem::write<float>(attr + 0x20 + 20*4, 0.f);
    }

    void draw_no_grass() {
        // Grass render flag — LOD trick via attribute
        // Em FF mobile é um float em um singleton de RenderSettings
        // simplificado: write via known static offset do dump
    }

    void draw_anti_flash(uintptr_t local_player) {
        uintptr_t attr = Mem::read<uintptr_t>(local_player + OFF::attributes_array);
        if (!attr) return;
        // flash_duration índice 25
        Mem::write<float>(attr + 0x20 + 25*4, 0.f);
    }

    // ---- ESP DRAW no framebuffer ----
    void draw_esp(const std::vector<Player>& players,
                  const Matrix4x4& vp,
                  int sw, int sh,
                  const Config& cfg,
                  const Player* aim_target) {

        for (auto& p : players) {
            if (!p.valid) continue;

            Vec2 head_scr, hip_scr, neck_scr;
            bool h_ok  = w2s(p.head, vp, sw, sh, head_scr);
            bool hi_ok = w2s(p.hip,  vp, sw, sh, hip_scr);
            bool n_ok  = w2s(p.neck, vp, sw, sh, neck_scr);
            if (!h_ok || !hi_ok) continue;

            uint32_t col = p.visible ? 0xFF00FF00 : 0xFFFF0000; // verde=visível, vermelho=wall
            if (&p == aim_target) col = 0xFFFFFF00; // amarelo=locked

            // BOX ESP
            if (cfg.box_esp) {
                float player_h = hip_scr.y - head_scr.y;
                float player_w = player_h * 0.4f;
                FB::draw_rect((int)(head_scr.x - player_w/2),
                              (int)head_scr.y,
                              (int)player_w,
                              (int)player_h, col);
            }

            // SKELETON ESP
            if (cfg.skeleton_esp && n_ok) {
                // head -> neck
                FB::draw_line((int)head_scr.x, (int)head_scr.y,
                              (int)neck_scr.x, (int)neck_scr.y, col);
                // neck -> hip
                FB::draw_line((int)neck_scr.x, (int)neck_scr.y,
                              (int)hip_scr.x,  (int)hip_scr.y, col);

                auto draw_limb = [&](Vec3 a, Vec3 b) {
                    Vec2 sa, sb;
                    if (w2s(a, vp, sw, sh, sa) && w2s(b, vp, sw, sh, sb))
                        FB::draw_line((int)sa.x,(int)sa.y,(int)sb.x,(int)sb.y, col);
                };
                draw_limb(p.neck, p.r_shoulder);
                draw_limb(p.r_shoulder, p.r_elbow);
                draw_limb(p.r_elbow, p.r_wrist);
                draw_limb(p.neck, p.l_shoulder);
                draw_limb(p.l_shoulder, p.l_elbow);
                draw_limb(p.l_elbow, p.l_wrist);
                draw_limb(p.hip, p.r_ankle);
                draw_limb(p.hip, p.l_ankle);
            }

            // NAME ESP
            if (cfg.name_esp && !p.name.empty()) {
                char upper[64]{};
                for (int i = 0; p.name[i] && i < 63; i++)
                    upper[i] = toupper(p.name[i]);
                FB::draw_text((int)head_scr.x - (int)p.name.size()*3,
                              (int)head_scr.y - 12,
                              upper, 0xFFFFFFFF);
            }

            // DISTANCE ESP
            if (cfg.distance_esp) {
                char dist_str[32];
                snprintf(dist_str, sizeof(dist_str), "%dm", (int)p.dist);
                FB::draw_text((int)hip_scr.x + 4, (int)hip_scr.y,
                              dist_str, 0xFFCCCCCC);
            }

            // LINE ESP (tracer from bottom-center)
            if (cfg.line_esp) {
                FB::draw_line(sw/2, sh, (int)hip_scr.x, (int)hip_scr.y, 0xFF4444FF);
            }

            // HEALTH ESP — barra lateral
            if (cfg.health_esp) {
                float hp_norm = p.hp / 200.f;
                if (hp_norm < 0) hp_norm = 0;
                if (hp_norm > 1) hp_norm = 1;
                float box_h = hip_scr.y - head_scr.y;
                int bar_x  = (int)(head_scr.x - box_h*0.2f - 6);
                int bar_y  = (int)head_scr.y;
                int bar_h  = (int)box_h;
                FB::draw_line(bar_x, bar_y, bar_x, bar_y + bar_h, 0xFF444444);
                uint32_t hp_col = hp_norm > 0.5f ? 0xFF00FF00 : 0xFFFF4400;
                FB::draw_line(bar_x, bar_y + (int)((1-hp_norm)*bar_h),
                              bar_x, bar_y + bar_h, hp_col);
            }
        }
    }

    // RADAR ESP — minimap no canto superior direito
    void draw_radar(const std::vector<Player>& players,
                    Vec3 local_pos, int sw, int sh) {
        int r_x = sw - 110, r_y = 10, r_sz = 100;
        // fundo
        for (int y = r_y; y < r_y+r_sz; y++)
            for (int x = r_x; x < r_x+r_sz; x++)
                FB::set_pixel(x, y, 0x99000000);
        // borda
        FB::draw_rect(r_x, r_y, r_sz, r_sz, 0xFF888888);
        // ponto local (centro)
        FB::set_pixel(r_x + r_sz/2, r_y + r_sz/2, 0xFF00FF00);

        float scale = 0.5f; // 1 metro = 0.5px no radar
        for (auto& p : players) {
            if (!p.valid) continue;
            float dx = p.head.x - local_pos.x;
            float dz = p.head.z - local_pos.z;
            int rx = r_x + r_sz/2 + (int)(dx * scale);
            int ry = r_y + r_sz/2 + (int)(dz * scale);
            if (rx < r_x || rx >= r_x+r_sz || ry < r_y || ry >= r_y+r_sz) continue;
            uint32_t col = p.visible ? 0xFFFF0000 : 0xFFFF8800;
            FB::set_pixel(rx,   ry,   col);
            FB::set_pixel(rx+1, ry,   col);
            FB::set_pixel(rx,   ry+1, col);
        }
    }

    // CROSSHAIR
    void draw_crosshair(int sw, int sh, int style) {
        int cx = sw/2, cy = sh/2;
        uint32_t col = 0xFFFFFFFF;
        switch (style) {
            case 0: break; // default do jogo
            case 1: // dot
                FB::set_pixel(cx, cy, col);
                break;
            case 2: // cross
                FB::draw_line(cx-10, cy, cx+10, cy, col);
                FB::draw_line(cx, cy-10, cx, cy+10, col);
                break;
            case 3: // circle 8px
                for (int a = 0; a < 360; a+=5) {
                    int px = cx + (int)(8*cosf(a*M_PI/180));
                    int py = cy + (int)(8*sinf(a*M_PI/180));
                    FB::set_pixel(px, py, col);
                }
                break;
        }
    }
}

// ============================================================
// PANEL UI — painel de texto no framebuffer (overlay lateral)
// ============================================================
namespace PanelUI {
    struct Toggle { const char* label; bool* val; };
    int g_sel = 0; // item selecionado pelo hotkey

    void draw(const Config& cfg, int sw, int sh) {
        if (cfg.streamer_mode) return;

        int px = 8, py = 50;
        uint32_t bg   = 0xCC111122;
        uint32_t hdr  = 0xFF4488FF;
        uint32_t on_c = 0xFF44FF44;
        uint32_t off_c= 0xFF884444;
        uint32_t sel_c= 0xFFFFFF00;

        // Fundo do painel
        for (int y = py; y < py + 390; y++)
            for (int x = px; x < px + 160; x++)
                FB::set_pixel(x, y, bg);

        auto draw_row = [&](int row, const char* label, bool val, bool selected) {
            int ry = py + 4 + row * 11;
            uint32_t col = selected ? sel_c : (val ? on_c : off_c);
            char buf[48];
            snprintf(buf, sizeof(buf), "%s %s", val ? "ON " : "OFF", label);
            FB::draw_text(px + 4, ry, buf, col);
        };

        // Cabeçalho
        FB::draw_text(px + 4, py + 2, "FF PANEL v4080", hdr);

        // Aim
        FB::draw_text(px + 4, py + 14, "--- AIM ---", 0xFF8888FF);
        draw_row(2,  "AIMBOT",       cfg.aimbot,        g_sel==0);
        draw_row(3,  "AIMLOCK",      cfg.aimlock,       g_sel==1);
        draw_row(4,  "AIM ASSIST",   cfg.aim_assist,    g_sel==2);
        draw_row(5,  "SILENT AIM",   cfg.silent_aim,    g_sel==3);
        draw_row(6,  "AUTO HS",      cfg.auto_headshot, g_sel==4);
        draw_row(7,  "TRIGGER",      cfg.aim_trigger,   g_sel==5);
        draw_row(8,  "PREDICTION",   cfg.aim_prediction,g_sel==6);

        // ESP
        FB::draw_text(px + 4, py + 100, "--- ESP ---", 0xFF8888FF);
        draw_row(10, "PLAYER ESP",   cfg.player_esp,    g_sel==7);
        draw_row(11, "BOX ESP",      cfg.box_esp,       g_sel==8);
        draw_row(12, "SKELETON",     cfg.skeleton_esp,  g_sel==9);
        draw_row(13, "NAME",         cfg.name_esp,      g_sel==10);
        draw_row(14, "DISTANCE",     cfg.distance_esp,  g_sel==11);
        draw_row(15, "HEALTH",       cfg.health_esp,    g_sel==12);
        draw_row(16, "LINE/TRACER",  cfg.line_esp,      g_sel==13);
        draw_row(17, "RADAR",        cfg.radar_esp,     g_sel==14);

        // Misc
        FB::draw_text(px + 4, py + 200, "--- MISC ---", 0xFF8888FF);
        draw_row(19, "NO RECOIL",    cfg.no_recoil,     g_sel==15);
        draw_row(20, "NO SPREAD",    cfg.no_spread,     g_sel==16);
        draw_row(21, "INF AMMO",     cfg.infinite_ammo, g_sel==17);
        draw_row(22, "FAST RELOAD",  cfg.fast_reload,   g_sel==18);
        draw_row(23, "AUTO FIRE",    cfg.auto_fire,     g_sel==19);
        draw_row(24, "MAGIC BULLET", cfg.magic_bullet,  g_sel==20);
        draw_row(25, "NO CLIP",      cfg.no_clip,       g_sel==21);
        draw_row(26, "FLY HACK",     cfg.fly_hack,      g_sel==22);
        draw_row(27, "SPEED HACK",   cfg.speed_hack,    g_sel==23);
        draw_row(28, "GHOST MODE",   cfg.ghost_mode,    g_sel==24);
        draw_row(29, "NO FOG",       cfg.no_fog,        g_sel==25);
        draw_row(30, "NO GRASS",     cfg.no_grass,      g_sel==26);
        draw_row(31, "ANTI-FLASH",   cfg.anti_flash,    g_sel==27);

        // Anti-ban status
        FB::draw_text(px + 4, py + 365, cfg.anti_ban ? "ANTI-BAN ON" : "ANTI-BAN OFF",
                      cfg.anti_ban ? on_c : off_c);
        FB::draw_text(px + 4, py + 376, cfg.anti_bl  ? "ANTI-BL  ON" : "ANTI-BL  OFF",
                      cfg.anti_bl  ? on_c : off_c);

        // Hotkeys hint
        FB::draw_text(px + 4, sh - 20, "VOL+/- NAV  PWR=TOG", 0xFF666666);
    }
}

// ============================================================
// HOTKEY THREAD — intercepta botões físicos via /dev/input
// VOL_DOWN = navegar, VOL_UP = navegar, POWER = toggle selected
// ============================================================
namespace Hotkeys {
    static const int MAX_TOGGLES = 28;
    static bool* toggles[MAX_TOGGLES];
    static int   toggle_count = 0;

    void register_toggle(bool* val) {
        if (toggle_count < MAX_TOGGLES)
            toggles[toggle_count++] = val;
    }

    void scan_thread(std::atomic<bool>& running) {
        // Encontra event device dos botões de volume/power
        int event_fd = -1;
        for (int i = 0; i < 20; i++) {
            char path[32];
            snprintf(path, sizeof(path), "/dev/input/event%d", i);
            int fd = open(path, O_RDONLY | O_NONBLOCK);
            if (fd < 0) continue;
            char name[64]{};
            ioctl(fd, EVIOCGNAME(sizeof(name)), name);
            if (strstr(name, "gpio") || strstr(name, "volume") || strstr(name, "key")) {
                event_fd = fd;
                LOGI("Hotkey device: %s (%s)", path, name);
                break;
            }
            close(fd);
        }
        if (event_fd < 0) { LOGE("No hotkey device"); return; }

        struct input_event ev;
        while (running) {
            ssize_t n = read(event_fd, &ev, sizeof(ev));
            if (n < (ssize_t)sizeof(ev)) { usleep(10000); continue; }
            if (ev.type != EV_KEY || ev.value != 1) continue;
            if (ev.code == KEY_VOLUMEDOWN) {
                PanelUI::g_sel = (PanelUI::g_sel + 1) % MAX_TOGGLES;
            } else if (ev.code == KEY_VOLUMEUP) {
                PanelUI::g_sel = (PanelUI::g_sel - 1 + MAX_TOGGLES) % MAX_TOGGLES;
            } else if (ev.code == KEY_POWER) {
                if (PanelUI::g_sel < toggle_count)
                    *toggles[PanelUI::g_sel] ^= true;
            }
        }
        close(event_fd);
    }
}

// ============================================================
// MAIN RENDER LOOP
// ============================================================
void render_loop(std::atomic<bool>& running, Config& cfg) {
    int sw = FB::width(), sh = FB::height();

    // Lê VP matrix do camera managed transform
    while (running) {
        // Limpa área ESP (não o jogo inteiro — só overlay)
        // Em produção usar transparent overlay via SurfaceFlinger/Overlay
        // Aqui limpamos uma região segura
        // ... (FB overlay logic, sem apagar o framebuffer do jogo)

        // Lê VP matrix — camera_managed_camera + 0x30 = managed camera ptr
        // VP matrix tipicamente em offset 0xDC do camera component
        Matrix4x4 vp{};
        // (preenchimento real via Mem::read<Matrix4x4>(...))
        // simplificado para o build — conectar ao camera_managed_camera offset

        const Player* aim_target = nullptr;

        {
            std::lock_guard<std::mutex> lk(GameReader::g_mtx);

            if (cfg.player_esp || cfg.box_esp || cfg.skeleton_esp ||
                cfg.name_esp   || cfg.distance_esp || cfg.health_esp ||
                cfg.line_esp) {
                Visual::draw_esp(GameReader::g_players, vp, sw, sh, cfg, aim_target);
            }
            if (cfg.radar_esp) {
                Visual::draw_radar(GameReader::g_players, GameReader::g_local_pos, sw, sh);
            }

            // Aimbot
            if (cfg.aimbot || cfg.aim_assist || cfg.silent_aim || cfg.auto_headshot) {
                aim_target = Aimbot::find_target(GameReader::g_players, vp, sw, sh,
                                                  cfg.aim_fov, cfg.aim_bone);
            }
            if (aim_target) {
                Vec2 scr;
                Vec3 target_bone = Aimbot::get_target_bone(*aim_target, cfg.aim_bone);
                if (w2s(target_bone, vp, sw, sh, scr)) {
                    if (cfg.aimbot || cfg.aimlock)
                        Aimbot::move_toward(scr, cfg.aim_smooth, sw, sh);
                    if (cfg.auto_headshot)
                        Aimbot::auto_headshot(*aim_target);
                    if (cfg.silent_aim)
                        Aimbot::silent_aim(*aim_target, GameReader::g_local_player);
                    if (cfg.magic_bullet)
                        WeaponHacks::magic_bullet(GameReader::g_local_player, aim_target);
                }
            }

            // Weapon / movement hacks via mem write
            uintptr_t lp = GameReader::g_local_player;
            if (lp) {
                if (cfg.no_recoil)     WeaponHacks::no_recoil(lp);
                if (cfg.no_spread)     WeaponHacks::no_spread(lp);
                if (cfg.infinite_ammo) WeaponHacks::infinite_ammo(lp);
                if (cfg.fast_reload)   WeaponHacks::fast_reload(lp);
                if (cfg.auto_fire)     WeaponHacks::auto_fire(lp, true);
                if (cfg.speed_hack)    MovementHacks::speed_hack(lp, cfg.speed_mult);
                if (cfg.fly_hack)      MovementHacks::fly_hack(lp, true);
                if (cfg.no_clip)       MovementHacks::no_clip(lp, true);
                if (cfg.ghost_mode)    MovementHacks::ghost_mode(lp, true);
                if (cfg.no_fog)        Visual::draw_no_fog(lp);
                if (cfg.anti_flash)    Visual::draw_anti_flash(lp);
                if (cfg.no_grass)      Visual::draw_no_grass();
            }
        }

        // Crosshair
        Visual::draw_crosshair(sw, sh, cfg.crosshair);

        // Panel UI
        PanelUI::draw(cfg, sw, sh);

        FB::flush();
        usleep(16666); // 60fps
    }
}

// ============================================================
// MAIN
// ============================================================
int main(int argc, char** argv) {
    LOGI("ff_panel v4080 starting — root required");

    // Anti-ban init
    AntiBan::init(argv[0]);

    // Config load
    Config cfg;
    CfgIO::load(cfg, cfg.cfg_path);

    // Framebuffer
    if (!FB::init()) { LOGE("FB init failed"); return 1; }

    // Memory
    if (!Mem::init()) { LOGE("Mem init failed — is FF running?"); return 1; }

    // Touch/uinput
    Touch::init();

    // Registra toggles em ordem do painel UI
    Hotkeys::register_toggle(&cfg.aimbot);
    Hotkeys::register_toggle(&cfg.aimlock);
    Hotkeys::register_toggle(&cfg.aim_assist);
    Hotkeys::register_toggle(&cfg.silent_aim);
    Hotkeys::register_toggle(&cfg.auto_headshot);
    Hotkeys::register_toggle(&cfg.aim_trigger);
    Hotkeys::register_toggle(&cfg.aim_prediction);
    Hotkeys::register_toggle(&cfg.player_esp);
    Hotkeys::register_toggle(&cfg.box_esp);
    Hotkeys::register_toggle(&cfg.skeleton_esp);
    Hotkeys::register_toggle(&cfg.name_esp);
    Hotkeys::register_toggle(&cfg.distance_esp);
    Hotkeys::register_toggle(&cfg.health_esp);
    Hotkeys::register_toggle(&cfg.line_esp);
    Hotkeys::register_toggle(&cfg.radar_esp);
    Hotkeys::register_toggle(&cfg.no_recoil);
    Hotkeys::register_toggle(&cfg.no_spread);
    Hotkeys::register_toggle(&cfg.infinite_ammo);
    Hotkeys::register_toggle(&cfg.fast_reload);
    Hotkeys::register_toggle(&cfg.auto_fire);
    Hotkeys::register_toggle(&cfg.magic_bullet);
    Hotkeys::register_toggle(&cfg.no_clip);
    Hotkeys::register_toggle(&cfg.fly_hack);
    Hotkeys::register_toggle(&cfg.speed_hack);
    Hotkeys::register_toggle(&cfg.ghost_mode);
    Hotkeys::register_toggle(&cfg.no_fog);
    Hotkeys::register_toggle(&cfg.no_grass);
    Hotkeys::register_toggle(&cfg.anti_flash);

    std::atomic<bool> running{true};

    // Threads
    std::thread reader_th([&]{ GameReader::loop(running, cfg); });
    std::thread hotkey_th([&]{ Hotkeys::scan_thread(running); });

    // Render loop na main thread
    render_loop(running, cfg);

    running = false;
    reader_th.join();
    hotkey_th.join();

    // Salva config ao sair
    CfgIO::save(cfg, cfg.cfg_path);
    LOGI("ff_panel shutdown clean");
    return 0;
}
