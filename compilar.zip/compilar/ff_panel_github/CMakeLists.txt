cmake_minimum_required(VERSION 3.18)
project(ff_panel CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Flags de compilação
set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -O2 -Wall -Wno-unused-variable -fvisibility=hidden -fstack-protector-strong")

add_executable(ff_panel src/ff_panel.cpp)

target_link_libraries(ff_panel
    log
    android
    dl
    pthread
    m
)
