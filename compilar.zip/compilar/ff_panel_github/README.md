# FF Panel v4080 — Build via GitHub Actions

Painel externo para Free Fire com root, anti-ban e todas as funções de aim/ESP/misc.

---

## Como compilar no GitHub (sem PC, sem Termux)

### 1. Cria uma conta no GitHub
https://github.com/signup

### 2. Cria um repositório novo
- Clica em **New repository**
- Nome: `ff-panel` (ou qualquer nome)
- Visibilidade: **Private** (recomendado)
- Clica em **Create repository**

### 3. Faz upload dos ficheiros
- Clica em **uploading an existing file**
- Faz upload de **todos os ficheiros deste zip** mantendo a estrutura de pastas:
  ```
  src/ff_panel.cpp
  CMakeLists.txt
  .github/workflows/build.yml
  README.md
  ```

### 4. Roda o build
- Vai em **Actions** no teu repositório
- Clica em **Build FF Panel arm64**
- Clica em **Run workflow** → **Run workflow**
- Aguarda ~2-3 minutos

### 5. Baixa o binário
- Quando terminar (ícone verde ✓)
- Clica no run → **Artifacts** → **ff_panel_arm64**
- Baixa o zip → extrai → tens o binário `ff_panel`

### 6. Executa no celular com root
```bash
# No Termux com root:
cp /sdcard/Download/ff_panel /data/local/tmp/
su -c 'chmod +x /data/local/tmp/ff_panel && /data/local/tmp/ff_panel'
```

---

## Estrutura do projeto

```
ff_panel_github/
├── .github/
│   └── workflows/
│       └── build.yml     ← GitHub Actions (compila automaticamente)
├── src/
│   └── ff_panel.cpp      ← código fonte completo
├── CMakeLists.txt        ← configuração de build
└── README.md             ← este ficheiro
```

---

## Funções

### Mira
- Aimbot, Aimlock, Aim Assist, Silent Aim
- Auto Headshot, Aim FOV, Aim Smooth
- Aim Prediction, Aim Target, Aim Bone, Aim Trigger

### ESP / Visual
- Player ESP, Box ESP, Skeleton ESP
- Name ESP, Distance ESP, Health ESP
- Line ESP (Tracer), Radar ESP, 3D ESP
- Vehicle ESP, Loot ESP

### Misc
- No Recoil, No Spread, Speed Hack, Fly Hack
- No Clip, Infinite Ammo, Fast Reload
- Auto Fire, Magic Bullet, Ghost Mode
- Anti-Flash, No Fog, No Grass

### Anti-Ban
- Process name spoof
- Anti-ptrace
- Maps scrub
- Timing jitter
- Signature wipe

---

## Hotkeys no celular

| Botão   | Função                  |
|---------|-------------------------|
| VOL -   | Navega para baixo       |
| VOL +   | Navega para cima        |
| POWER   | Liga/desliga selecionado|

---

v4080
